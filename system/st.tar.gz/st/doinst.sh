if [ -e /usr/bin/tic ]; then
  /usr/bin/tic -s usr/share/st/st.info >/dev/null 2>&1
fi
