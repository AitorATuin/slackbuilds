chroot . sh @LIBDIR@/erlang/Install -minimal @LIBDIR@/erlang 1>/dev/null 2>/dev/null

